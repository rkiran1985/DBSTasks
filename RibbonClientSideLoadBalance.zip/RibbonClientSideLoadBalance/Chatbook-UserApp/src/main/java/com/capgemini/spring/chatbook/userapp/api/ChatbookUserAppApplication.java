package com.capgemini.spring.chatbook.userapp.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
@RestController
@RibbonClient(name = "Chatbook",configuration=RibbonConfiguration.class)
public class ChatbookUserAppApplication {

	@Autowired
	RestTemplate template;
	
	public static void main(String[] args) {
		SpringApplication.run(ChatbookUserAppApplication.class, args);
	}

	@Bean
	@LoadBalanced
	public RestTemplate template()
	{
		return new RestTemplate();
	}
	
	@GetMapping("/invoke")
	public String invokeChatBook() {
	
		String url = "http://Chatbook/chatbook-application/chat";
		//if our ChatBook app runs on single port need to mention above but it's running on 8081 8082 8083 so instead of port No mention Chatbook
		return template.getForObject(url, String.class);
		
		
	}
}
