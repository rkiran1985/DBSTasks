package com.capgemini.spring.chatbook.userapp.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbookUserAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
