package com.capgemini.spring.chatbook.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
