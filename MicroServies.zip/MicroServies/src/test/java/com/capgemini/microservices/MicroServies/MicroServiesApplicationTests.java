package com.capgemini.microservices.MicroServies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroServiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
