package com.capgemini.microservices.microservies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroServiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroServiesApplication.class, args);
	}

}
