package com.capgemini.microservices.microservies;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.microservices.microservies.model.User;
import com.capgemini.microservices.microservies.service.UserService;

@RestController
public class MicroServicesController {
	
	@Autowired
	UserService userService;
	
	@GetMapping("/user")
	public User getUser()
	{
		return userService.getUser();
	}

	
	@GetMapping("/users")
	public List<User> getUsersList()
	{
		return userService.getUsers();
	}

}
