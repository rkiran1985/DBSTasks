package com.capgemini.microservices.microservies.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.microservices.microservies.model.User;

@Service
public class UserService {

	public User getUser()
	{
		return new User(1, "Kiran");
	}
	
	public List<User> getUsers()
	{
		List<User> usersList= new ArrayList<>();
		User user1 = new User(1, "Kiran");
		User user2 = new User(2, "Sagar");
		User user3 = new User(3, "Vamsi");
		User user4 = new User(4, "Srinivas");
		User user5 = new User(5, "Venkatagiri");
		User user6 = new User(6, "Murthy");
		
		usersList.add(user1);
		usersList.add(user2);
		usersList.add(user3);
		usersList.add(user4);
		usersList.add(user5);
		usersList.add(user6);
		
		return usersList; 
	}
	
}
