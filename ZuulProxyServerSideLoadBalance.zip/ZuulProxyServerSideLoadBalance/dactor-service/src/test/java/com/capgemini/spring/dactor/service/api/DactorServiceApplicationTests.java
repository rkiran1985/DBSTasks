package com.capgemini.spring.dactor.service.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DactorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
