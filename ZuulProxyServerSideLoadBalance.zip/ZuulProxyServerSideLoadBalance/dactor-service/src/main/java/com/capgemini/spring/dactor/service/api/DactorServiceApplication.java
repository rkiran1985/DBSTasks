package com.capgemini.spring.dactor.service.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class DactorServiceApplication {

	@GetMapping("/getDS")
	public String getDoctorService()
	{
		return "Doctor Micro Services called...";
	}
	
	@GetMapping("/welcome/{name}")
	public String wish(@PathVariable String name)
	{
		return "Hi "+name+ "Welcome To Doctor Micro Services";
	}
	
	
	public static void main(String[] args) {
		SpringApplication.run(DactorServiceApplication.class, args);
	}

}
