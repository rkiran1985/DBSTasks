package com.capgemini.spring.hospital.gateway.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
