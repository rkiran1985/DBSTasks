package com.capgemini.security.oauth.securitydbexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityDbExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityDbExampleApplication.class, args);
	}

}
